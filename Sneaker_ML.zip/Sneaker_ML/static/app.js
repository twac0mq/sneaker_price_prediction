
// $(document).ready(function(){
//   d3.json("./data/UNC_OW_9.json",function(error, Data) {
//     alert(Data);
//   })
// })
d3.csv("static/unc_ow_9.csv", function(error, Data) {
  if (error) return console.warn(error);

  console.log(Data);
});      


