var exp = document.querySelector('select[name="chart-selector"]');
