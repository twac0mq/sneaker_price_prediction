import numpy as np
from flask import Flask, render_template, request, jsonify
import pickle

app = Flask(__name__)


@app.route('/')
def home():
    return render_template("index2.html")

@app.route('/index2')
def home2():
    return render_template("index2.html")

@app.route('/contact')
def contact():
    return render_template("contact.html")  # render a template

@app.route('/about')
def about():
    return render_template("about.html")  # render a template
    
@app.route('/predict',methods=['POST'])
def predict():
    # Get the data from the POST request.
    if request.method == "POST":
        #data = request.get_json(force=True)
        print(request.form)
        if(request.form["chart-selector"]=='0'):
            print("I'm 0")
            model2 = pickle.load(open('./model/model.pkl','rb'))
            print(request.form['exp'])
            data = float(request.form['exp'])
            print("Data", model2.predict([[data]]))
            # Make prediction using model loaded from disk as per the data.
            prediction = model2.predict([[data]])
        elif(request.form["chart-selector"]=="1"):
            print("I'm 1")
            model2 = pickle.load(open('./model/model2.pkl','rb'))
            print(request.form['exp'])
            data = float(request.form['exp'])
            print("Data", model2.predict([[data]]))
            # Make prediction using model loaded from disk as per the data.
            prediction = model2.predict([[data]])
        elif(request.form["chart-selector"]=="2"):
            print("I'm 1")
            model2 = pickle.load(open('./model/model3.pkl','rb'))
            print(request.form['exp'])
            data = float(request.form['exp'])
            print("Data", model2.predict([[data]]))
            # Make prediction using model loaded from disk as per the data.
            prediction = model2.predict([[data]])
        elif(request.form["chart-selector"]=="4"):
            model2 = pickle.load(open('./model/model4.pkl','rb'))
            print(request.form['exp'])
            data = float(request.form['exp'])
            print("Data", model2.predict([[data]]))
            # Make prediction using model loaded from disk as per the data.
            prediction = model2.predict([[data]])
        else:
            print("I'm else")
            # model2 = pickle.load(open('./model/model2.pkl','rb'))
            # print(request.form['exp'])
            # data = float(request.form['exp'])
            # print("Data", model2.predict([[data]]))


            model2 = pickle.load(open('./model/model.pkl','rb'))
            print(request.form['exp'])
            data = float(request.form['exp'])
            print("Data", model2.predict([[data]]))
            # Make prediction using model loaded from disk as per the data.
            prediction = model2.predict([[data]])
      

        # Take the first value of prediction
        output = prediction[0]

        return render_template("travis_white_results.html", output=output, date=data)



if __name__ == '__main__':
    app.run(debug=False)

